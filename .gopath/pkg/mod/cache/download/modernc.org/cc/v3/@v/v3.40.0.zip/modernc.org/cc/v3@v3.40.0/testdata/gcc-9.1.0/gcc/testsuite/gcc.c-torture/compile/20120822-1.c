int a;
int c;
int b;
void shr_long(int d, unsigned char s)
{
 long long dvd, div, mod;
 dvd = b;
 mod = dvd % s;
 if (((c >> ((mod & 0xff) % 32)) & 1) == 0)
  a = 1;
}
