#define FUNC_LIKE(a) ( a )
#define FUNC_LIKE(b) ( b ) // different parameter spelling
