# cc/v3

Package CC is a C99 compiler front end.

Most of the functionality is now working.

Installation

    $ go get -u modernc.org/cc/v3

Documentation: [godoc.org/modernc.org/cc/v3](http://godoc.org/modernc.org/cc/v3)
