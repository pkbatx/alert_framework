gcc gen.c ; ./a.out | cpp > table.c ; rm -f a.out
