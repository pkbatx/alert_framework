int main() {
	__ccgo_dmesg("%s:%d: test", __FILE__, __LINE__);
}
