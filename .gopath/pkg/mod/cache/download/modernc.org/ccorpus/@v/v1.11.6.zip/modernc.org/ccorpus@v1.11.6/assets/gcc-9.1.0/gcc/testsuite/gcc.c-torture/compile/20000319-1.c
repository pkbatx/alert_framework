struct foo
{
  long x;
  char y;
  long boom[0];
};
