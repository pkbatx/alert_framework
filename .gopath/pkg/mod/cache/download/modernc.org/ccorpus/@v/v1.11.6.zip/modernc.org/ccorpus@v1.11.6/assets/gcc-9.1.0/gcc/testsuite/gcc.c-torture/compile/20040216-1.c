int foo (int a, int b, int c, int d)
{
  return ~a & ~b & ~c & ~d;
}
