indent -linux *.c
rm -f *~
